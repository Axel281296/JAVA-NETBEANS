/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglos1;

/**
 *
 * @author User
 */
public class sub {
    
    
    int[] a ={3,5,6,8,4,7,8,5,3,1};
    int[] b ={3,4,6,8,9,1,2,3,0,9};
    
    public void proceso()
    {
    int valor1 = a[3] % (b[2])/2;
    int valor2 = b[1] - a[9];
    int valor3 = a[1] + a[1+2];
    int valor4 = a[5] + b[5];
    int valor5 = a[3] / b[2] / 2;
    int valor6 = b[1] + b[1];
    
    System.out.println(valor1);
    System.out.println(valor2);
    System.out.println(valor3);
    System.out.println(valor4);
   System.out.println(valor5);
   System.out.println(valor6);
    
    
    
    
    }
}
